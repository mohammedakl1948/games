# FlApPy-BiRd


A Flappy Bird Clone made using python-pygame


Simple Flappy Bird Game project is written in Python. The project file contains asset files, python scripts (flappybird.py). The gameplay Graphics is good enough and the controls are simple for the users. Talking about the gameplay, it’s one of the most addictive and played games for all. All the playing methods are too simple just like the real one. All you have to do is just try to stay in the middle of the screen until long green pipes appear in front of you. Here, the user has to control the bird flapping up, down using Spacebar, without touching pipes in order to score game points. This means the more you pass through green pipes, more will be the game points. A simple GUI is provided for the easy gameplay. The gameplay design is so simple that user won’t find it difficult to use and navigate.

This simple flappy bird game provides the simplest gameplay of flappy bird. Though the gameplay is a bit laggy but the gameplay works well. In order to run the project, you must have installed Python, Pygame on your PC. This is a simple GUI Based game written for the beginners. Simple Flappy Bird Game in Python project with source code is free to download. Use for education purpose only!
